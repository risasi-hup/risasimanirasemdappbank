#!/usr/bin/env python3
"""Logo üretici: kaynak PNG'lerden cüzdan/borsa boyutlarını (32/64/128/256) üretir.
Kullanım: python3 tools/make_logos.py rsm kaynak-512.png   (çıktı: logos/rsm-32.png ...)
Yuvarlak, şeffaf köşeli küçük sürümler üretir; 256 sürümü Trust Wallet sınırı (<100 KB) için optimize eder."""
import sys, base64, io
from PIL import Image, ImageDraw, ImageChops

def circle(im, n):
    im = im.convert('RGBA'); big = im.size[0]
    m = Image.new('L', (big*4, big*4), 0); ImageDraw.Draw(m).ellipse((0, 0, big*4-1, big*4-1), fill=255)
    m = m.resize(im.size, Image.LANCZOS); im.putalpha(ImageChops.multiply(im.getchannel('A'), m))
    return im.resize((n, n), Image.LANCZOS)

def opt256(im, path):
    for c in (256, 192, 128, 64):
        q = im.convert('RGBA').quantize(c, method=2, dither=0)   # 2 = FASTOCTREE (alfa korunur)
        q.save(path, optimize=True)
        import os
        if os.path.getsize(path) < 100_000: return c

if __name__ == '__main__':
    name, src = sys.argv[1], sys.argv[2]
    base = Image.open(src).convert('RGBA').resize((512, 512), Image.LANCZOS)
    for n in (32, 64, 128): circle(base, n).save(f'logos/{name}-{n}.png', optimize=True)
    print('256 renk sayısı:', opt256(base.resize((256, 256), Image.LANCZOS), f'logos/{name}-256.png'))
    buf = io.BytesIO(); circle(base, 32).save(buf, 'PNG', optimize=True)
    print('32x32 data URI:', 'data:image/png;base64,' + base64.b64encode(buf.getvalue()).decode())
